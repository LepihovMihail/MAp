﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Map22IS_21
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Cleaner()
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
        }
        private void button9_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Start 1";
            label7.Text = "MCC Luzhniki";
            pictureBox3.Visible = true; pictureBox3.Location = new Point(550, 104);
            label1.Visible = true; label1.Text = "Drinks"; label1.Location = new Point(614, 107);

            pictureBox4.Visible = true; pictureBox4.Location = new Point(550, 172);
            label2.Visible = true; label2.Text = "Energy bar"; label2.Location = new Point(614, 176);

            pictureBox5.Visible = true; pictureBox5.Location = new Point(550, 243);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(614, 243);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Start 1";
            label7.Text = "Gorky park";
            pictureBox4.Visible = true; pictureBox4.Location = new Point(550, 104);
            label2.Visible = true; label2.Text = "Energy bar"; label2.Location = new Point(614, 107);

            pictureBox5.Visible = true; pictureBox5.Location = new Point(550, 243);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(614, 243);

            pictureBox7.Visible = true; pictureBox7.Location = new Point(550, 172);
            label5.Visible = true; label5.Text = "Medical"; label5.Location = new Point(614, 176);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Start 3";
            label7.Text = "Vorobyovy Gory";
            pictureBox4.Visible = true; pictureBox4.Location = new Point(550, 104);
            label2.Visible = true; label2.Text = "Energy bar"; label2.Location = new Point(614, 107);

            pictureBox5.Visible = true; pictureBox5.Location = new Point(550, 172);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(614, 176);

            pictureBox6.Visible = true; pictureBox6.Location = new Point(550, 243);
            label4.Visible = true; label4.Text = "Information"; label4.Location = new Point(614, 243);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Station 1";
            label7.Text = "Gorky park";
            pictureBox4.Visible = true; pictureBox4.Location = new Point(550, 104);
            label2.Visible = true; label2.Text = "Energy Bar"; label2.Location = new Point(614, 107);

            pictureBox5.Visible = true; pictureBox5.Location = new Point(550, 172);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(614, 176);

            pictureBox6.Visible = true; pictureBox6.Location = new Point(550, 243);
            label4.Visible = true; label4.Text = "Information"; label4.Location = new Point(614, 243);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Station 2";
            label7.Text = "Gorky park";
            pictureBox5.Visible = true; pictureBox5.Location = new Point(550, 104);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(614, 107);

            pictureBox6.Visible = true; pictureBox6.Location = new Point(550, 172);
            label4.Visible = true; label4.Text = "Information"; label4.Location = new Point(614, 176);

            pictureBox7.Visible = true; pictureBox7.Location = new Point(550, 243);
            label5.Visible = true; label5.Text = "Medical"; label5.Location = new Point(614, 243);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Station 3";
            label7.Text = "Gorky park";
            pictureBox5.Visible = true; pictureBox5.Location = new Point(550, 104);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(614, 107);

            pictureBox6.Visible = true; pictureBox6.Location = new Point(550, 172);
            label4.Visible = true; label4.Text = "Information"; label4.Location = new Point(614, 176);
            
            pictureBox7.Visible = true; pictureBox7.Location = new Point(550, 243);
            label5.Visible = true; label5.Text = "Medical"; label5.Location = new Point(614, 243);
            
            pictureBox3.Visible = true; pictureBox3.Location = new Point(552, 310);
            label1.Visible = true; label1.Text = "Drinks"; label1.Location = new Point(616, 312);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Station 4";
            label7.Text = "MFA";
            pictureBox7.Visible = true; pictureBox7.Location = new Point(550, 104);
            label5.Visible = true; label5.Text = "Medical"; label5.Location = new Point(614, 107);
            pictureBox4.Visible = true; pictureBox4.Location = new Point(550, 172);
            label2.Visible = true; label2.Text = "Energy bar"; label2.Location = new Point(614, 176);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Station 5";
            label7.Text = "Park Kultury";
            pictureBox3.Visible = true; pictureBox3.Location = new Point(550, 104);
            label1.Visible = true; label1.Text = "Drinks"; label1.Location = new Point(614, 107);
            pictureBox5.Visible = true; pictureBox5.Location = new Point(550, 172);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(614, 176);
            pictureBox6.Visible = true; pictureBox6.Location = new Point(550, 243);
            label4.Visible = true; label4.Text = "Information"; label4.Location = new Point(614, 243);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Station 6";
            label7.Text = "Frunzenskaya Nab.";

            pictureBox3.Visible = true; pictureBox3.Location = new Point(550, 104);
            label1.Visible = true; label1.Text = "Drinks"; label1.Location = new Point(614, 107);
            
            pictureBox6.Visible = true; pictureBox6.Location = new Point(550, 172);
            label4.Visible = true; label4.Text = "Information"; label4.Location = new Point(614, 176);
            
            pictureBox4.Visible = true; pictureBox4.Location = new Point(550, 243);
            label2.Visible = true; label2.Text = "Energy bar"; label2.Location = new Point(614, 243);

            pictureBox5.Visible = true; pictureBox5.Location = new Point(552, 310);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(616, 312);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Station 7";
            label7.Text = "RAS Presidium building";
            pictureBox7.Visible = true; pictureBox7.Location = new Point(550, 104);
            label5.Visible = true; label5.Text = "Medical"; label5.Location = new Point(614, 107);
        }
        private void button8_Click(object sender, EventArgs e)
        {
            Cleaner();
            label6.Text = "Station 8";
            label7.Text = "Ulitsa Luzhniki";
            pictureBox3.Visible = true; pictureBox3.Location = new Point(550, 107);
            label1.Visible = true; label1.Text = "Drinks"; label1.Location = new Point(614, 107);

            pictureBox7.Visible = true; pictureBox7.Location = new Point(550, 172);
            label5.Visible = true; label5.Text = "Medical"; label5.Location = new Point(614, 176);
            
            pictureBox5.Visible = true; pictureBox5.Location = new Point(550, 243);
            label3.Visible = true; label3.Text = "Toilets"; label3.Location = new Point(614, 243);

            pictureBox4.Visible = true; pictureBox4.Location = new Point(552, 310);
            label2.Visible = true; label2.Text = "Energy bar"; label2.Location = new Point(616, 312);

            pictureBox6.Visible = true; pictureBox6.Location = new Point(550, 384);
            label4.Visible = true; label4.Text = "Information"; label4.Location = new Point(614, 384);
        }
    }
}
